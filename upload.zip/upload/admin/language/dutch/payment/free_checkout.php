<?php
// Heading
$_['heading_title']      = 'Kostenloos bestellen';

// Text
$_['text_payment']       = 'Betaling';
$_['text_success']       = 'Succes: Instellingen gewijzigd!';
$_['text_edit']          = 'Wijzigen';

// Entry
$_['entry_order_status'] = 'Bestelstatus';
$_['entry_status']       = 'Status';
$_['entry_sort_order']   = 'Sorteervolgorde';

// Error
$_['error_permission']   = 'Waarschuwing: U heeft geen rechten om deze instellingen te wijzigen!';