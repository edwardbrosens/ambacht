<?php
// Heading
$_['heading_title']     = 'Klant Online Rapport';

// Text 
$_['text_list']         = 'Lijst';
$_['text_guest']        = 'Gasten';

// Column
$_['column_ip']         = 'IP-adres';
$_['column_customer']   = 'Klant';
$_['column_url']        = 'Laatst bezochte pagina';
$_['column_referer']    = 'Referer';
$_['column_date_added'] = 'Laatste klik';
$_['column_action']     = 'Aktie';

// Entry
$_['entry_ip']          = 'IP-adres';
$_['entry_customer']    = 'Klant';