<?php
// Heading
$_['heading_title']    = 'Marketing Rapport';

// Text
$_['text_list']         = 'Lijst';
$_['text_all_status']   = 'Alle Statussen';

// Column
$_['column_campaign']  = 'Campaigne Naam';
$_['column_code']      = 'Code';
$_['column_clicks']    = 'Aantal klikken';
$_['column_orders']    = 'Aantal bestellingen';
$_['column_total']     = 'Totaal';

// Entry
$_['entry_date_start'] = 'Begindatum';
$_['entry_date_end']   = 'Einddatum';
$_['entry_status']     = 'Bestelstatus';