<?php
// Heading
$_['heading_title']    = 'Kortingsbonnen Rapport';

// Text
$_['text_list']        = 'Lijst';

// Column
$_['column_name']      = 'Kortingsbon naam';
$_['column_code']      = 'Code';
$_['column_orders']    = 'Bestellingen';
$_['column_total']     = 'Totaal';
$_['column_action']    = 'Aktie';

// Entry
$_['entry_date_start'] = 'Begindatum';
$_['entry_date_end']   = 'Einddatum';