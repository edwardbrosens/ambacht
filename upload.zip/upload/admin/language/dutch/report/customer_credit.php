<?php
// Heading
$_['heading_title']         = 'Klant Krediet Rapport';

// Column
$_['text_list']             = 'Lijst';
$_['column_customer']       = 'Klantnaam';
$_['column_email']          = 'E-mail';
$_['column_customer_group'] = 'Klantgroup';
$_['column_status']         = 'Status';
$_['column_total']          = 'Totaal';
$_['column_action']         = 'Aktie';

// Entry
$_['entry_date_start']      = 'Begindatum';
$_['entry_date_end']        = 'Einddatum';