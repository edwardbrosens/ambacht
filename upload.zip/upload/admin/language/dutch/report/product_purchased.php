<?php
// Heading
$_['heading_title']     = 'Verkochte Producten Rapport';

// Text
$_['text_list']         = 'Lijst';
$_['text_all_status']   = 'Alle statussen';

// Column
$_['column_date_start'] = 'Begindatum';
$_['column_date_end']   = 'Eindatum';
$_['column_name']       = 'Naam';
$_['column_model']      = 'Model';
$_['column_quantity']   = 'Aantal';
$_['column_total']      = 'Totaal';

// Entry
$_['entry_date_start']  = 'Begindatum';
$_['entry_date_end']    = 'Eindatum';
$_['entry_status']      = 'Bestelstatus';