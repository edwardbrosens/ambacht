<?php
// Heading
$_['heading_title']  = 'Bekeken Producten Rapport';

// Text
$_['text_list']      = 'Lijst';
$_['text_success']   = 'Succes: Rapport ge-reset!';

// Column
$_['column_name']    = 'Naam';
$_['column_model']   = 'Model';
$_['column_viewed']  = 'Bekeken';
$_['column_percent'] = 'Percentage';

// Error
$_['error_permission']  = 'Waarschuwing: U heeft geen rechten deze instellingen te wijzigen!';