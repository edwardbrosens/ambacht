<?php
// Heading
$_['heading_title']    = 'Google Sitemap';

// Text 
$_['text_feed']        = 'Product Feeds';
$_['text_success']     = 'Succes: Instellingen gewijzigd!';
$_['text_list']    	   = 'Layoutlijst';

// Entry
$_['entry_status']     = 'Status';
$_['entry_data_feed']  = 'Data Feed Url';

// Error
$_['error_permission'] = 'Waarschuwing: U heeft geen rechten deze instellingen te wijzigen!';