<?php
// Heading
$_['heading_title']     = 'Besteltotalen';

// Text
$_['text_success']      = 'Succes: Instellingen gewijzigd!';
$_['text_list']    	    = 'Layoutlijst';

// Column
$_['column_name']       = 'Besteltotalen';
$_['column_status']     = 'Status';
$_['column_sort_order'] = 'Sorteervolgorde';
$_['column_action']     = 'Aktie';

// Error
$_['error_permission']  = 'Waarschuwing: U heeft geen rechten deze instellingen te wijzigen!';