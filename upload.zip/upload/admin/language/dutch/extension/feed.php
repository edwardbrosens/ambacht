<?php
// Heading
$_['heading_title'] = 'Product Feeds';

// Text
$_['text_success']      = 'Succes: Instellingen gewijzigd!';
$_['text_list']         = 'Lijst';

// Column
$_['column_name']   = 'Product Feed';
$_['column_status'] = 'Status';
$_['column_action'] = 'Aktie';

// Error
$_['error_permission'] = 'Waarschuwing: U heeft geen rechten deze instellingen te wijzigen!';