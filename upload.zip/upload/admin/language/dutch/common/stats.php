<?php
$_['text_complete_status']   = 'Afgehandelde bestellingen'; 
$_['text_processing_status'] = 'Bestellingen in behandeling'; 
$_['text_other_status']      = 'Overige bestelstatussen'; 