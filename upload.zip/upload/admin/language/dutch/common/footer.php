<?php
// Text
$_['text_footer'] 	= '<a href="http://www.opencart.nl">OpenCart Nederland</a> &copy; 2009-' . date('Y') . ' Alle rechten voorbehouden.<br /><b>Versie %s</b>';
$_['text_version'] 	= 'Versie %s';