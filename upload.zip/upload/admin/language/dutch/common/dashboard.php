<?php
// Heading
$_['heading_title']                = 'Dashboard';

// Text
$_['text_order_total']  	= 'Totaal bestellingen';
$_['text_customer_total'] 	= 'Totaal klant(en)';
$_['text_sale_total']   	= 'Totaal verkopen';
$_['text_online_total']     = 'Totaal nu Online';
$_['text_map']              = 'Wereldkaart';
$_['text_sale']             = 'Verkoopanalize';
$_['text_activity']     	= 'Recente Activiteit';
$_['text_recent']   		= 'Laatste bestellingen';
$_['text_order']        	= 'Bestellingen';
$_['text_customer']     	= 'Klanten';
$_['text_day']          	= 'Vandaag';
$_['text_week']         	= 'Week';
$_['text_month']        	= 'Maand';
$_['text_year']         	= 'Jaar';
$_['text_view']             = 'Meer...';

// Error
$_['error_install'] = 'Waarschuwing: De installatiemap bestaat nog! Verwijder deze map ivm. de veiligheid!';