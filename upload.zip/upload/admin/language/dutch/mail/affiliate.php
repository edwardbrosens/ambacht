<?php
// Text
$_['text_approve_subject']      = '%s - Uw Affiliate account is geactiveerd!';
$_['text_approve_welcome']      = 'Hartelijk dank u voor uw registratie bij %s!';
$_['text_approve_login']        = 'Uw account is aangemaakt. U kunt met uw e-mailadres en wachtwoord inloggen op het volgende internet adres:';
$_['text_approve_services']     = 'Na inloggen kunt u uw tracking codes genereren, commissie betalingen controlleren en uw accountgegevens aanpassen.';
$_['text_approve_thanks']       = 'Met vriendelijke groeten,';
$_['text_transaction_subject']  = '%s - Commissie';
$_['text_transaction_received'] = 'U heeft %s aan commissie ontvangen!';
$_['text_transaction_total']    = 'Uw totaal aan commissie is nu: %s.';