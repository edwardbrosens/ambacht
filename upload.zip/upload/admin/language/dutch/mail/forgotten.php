<?php
// Text
$_['text_subject']  = '%s - wachtwoord reset aanvraag';
$_['text_greeting'] = 'Er is een nieuw wachtwoord aangevraagd voor de %s administratie.';
$_['text_change']   = 'Om uw wachtwoord te resetten klik op onderstaande link:';
$_['text_ip']       = 'Aanvraag gedaan vanaf IP-adres: %s';