<?php
// Text
$_['text_subject']  = 'U heeft een cadeaubon gekregen van %s';
$_['text_greeting'] = 'Gefeliciteerd, U heeft een cadeaubon gekregen met een waarde van %s';
$_['text_from']     = 'Deze bon heeft u gekregen van %s';
$_['text_message']  = 'Bij deze bon hoort het volgende bericht';
$_['text_redeem']   = 'Om deze cadeaubon te gebruiken noteert u eerst de volgende code <b>%s</b>, hierna kunt u op de link hieronder klikken. De door u genoteerde code geeft u in tijdens het afrekenen';
$_['text_footer']   = 'U kunt op deze e-mail reageren als u vragen heeft.';