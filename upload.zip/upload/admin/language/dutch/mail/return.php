<?php
// Text
$_['text_subject']       = '%s - update voor retouraanvraag %s';
$_['text_return_id']     = 'Retournummer';
$_['text_date_added']    = 'Retourdatum:';
$_['text_return_status'] = 'Uw retouraanvraag heeft de volgende (nieuwe) status:';
$_['text_comment']       = 'Onze opmerkingen bij uw aanvraag zijn:';
$_['text_footer']        = 'U kunt op deze e-mail reageren indien u vragen heeft.';