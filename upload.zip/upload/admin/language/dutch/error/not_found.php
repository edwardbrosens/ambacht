<?php
// Heading
$_['heading_title'] = 'Pagina niet gevonden!';

// Text
$_['text_not_found'] = 'De pagina die u zoekt kan niet (meer) worden gevonden. Neem desnoods contact met ons op.';