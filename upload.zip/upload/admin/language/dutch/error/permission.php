<?php
// Heading
$_['heading_title'] = 'Toegang geweigerd!';

// Text
$_['text_permission'] = 'U heeft geen toegang tot deze pagina. Neem desnoods contact met ons op.';