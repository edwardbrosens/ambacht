<?php
// Heading
$_['heading_title'] = 'Totaal bestellingen';

// Text
$_['text_view']     = 'Meer...';