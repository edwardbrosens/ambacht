<?php
// Heading
$_['heading_title'] = 'Wereldkaart';

$_['text_order']    = 'Bestellingen';
$_['text_sale']     = 'Verkoop';