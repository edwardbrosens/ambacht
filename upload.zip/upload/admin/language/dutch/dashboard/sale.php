<?php
// Heading
$_['heading_title'] = 'Totaal verkopen';

// Text
$_['text_view']     = 'Meer...';