<?php
// Heading
$_['heading_title']     = 'Laatste bestellingen';

// Column
$_['column_order_id']   = 'Bestelnummer';
$_['column_customer']   = 'Klant';
$_['column_status']     = 'Status';
$_['column_total']      = 'Totaal';
$_['column_date_added'] = 'Besteldatum';
$_['column_action']     = 'Aktie';