<?php
// Heading
$_['heading_title'] = 'Totaal klanten';

// Text
$_['text_view'] = 'Meer...';