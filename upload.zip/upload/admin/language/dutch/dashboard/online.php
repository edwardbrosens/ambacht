<?php
// Heading
$_['heading_title'] = 'Bezoekers online';

// Text
$_['text_view']     = 'Meer...';