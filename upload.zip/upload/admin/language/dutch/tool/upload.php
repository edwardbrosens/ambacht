<?php
// Heading
$_['heading_title']     = 'Uploads';

// Text
$_['text_success']      = 'Succes: Instellingen gewijzigd!';
$_['text_list']         = 'Lijst';

// Column
$_['column_name']       = 'Uploadnaam';
$_['column_filename']   = 'Bestandsnaam';
$_['column_date_added'] = 'Datum';
$_['column_action']     = 'Aktie';

// Entry
$_['entry_name']        = 'Uploadnaam';
$_['entry_filename']    = 'Bestandsnaam';
$_['entry_date_added'] 	= 'Datum';

// Error
$_['error_permission']  = 'Waarschuwing: U heeft geen rechten deze instellingen te wijzigen!';