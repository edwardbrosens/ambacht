<?php
// Heading
$_['heading_title'] = 'Error log';

// Text
$_['text_success'] = 'Succes: Het foutmelding(en) log is leeg gemaakt!';
$_['text_list']    = 'Lijst';

// Error
$_['error_warning']		= 'Waarschuwing: Uw error-log bestand %s is %s groot!';
$_['error_permission']	= 'Waarschuwing: U heeft geen rechten om het error-log te legen!';