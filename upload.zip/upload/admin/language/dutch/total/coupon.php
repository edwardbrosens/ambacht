<?php
// Heading
$_['heading_title']    = 'Kortingsbon';

// Text
$_['text_total']       = 'Besteltotalen';
$_['text_success']     = 'Succes: Instellingen gewijzigd!';
$_['text_edit']        = 'Wijzigen';

// Entry
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sorteervolgorde';

// Error
$_['error_permission'] = 'Waarschuwing: U heeft geen rechten deze instellingen te wijzigen!';