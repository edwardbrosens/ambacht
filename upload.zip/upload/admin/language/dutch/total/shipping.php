<?php
// Heading
$_['heading_title']    = 'Verzendkosten';

// Text
$_['text_total']       = 'Besteltotalen';
$_['text_success']     = 'Succes: Instellingen gewijzigd!';
$_['text_edit']        = 'Wijzigen';

// Entry
$_['entry_estimator']  = 'Verzendkosten berekening';
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sorteervolgorde';

// Error
$_['error_permission'] = 'Waarschuwing: U heeft geen rechten deze instellingen te wijzigen!';