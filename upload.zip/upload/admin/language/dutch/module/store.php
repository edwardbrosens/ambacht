<?php
// Heading
$_['heading_title'] = 'Winkel';

// Text
$_['text_module']   = 'Modules';
$_['text_success']  = 'Succes: Instellingen gewijzigd!';
$_['text_edit']     = 'Instellingen wijzigen';

// Entry
$_['entry_admin']         = 'ALLEEN Administrateurs';
$_['entry_status']        = 'Status';

// Error
$_['error_permission']    = 'Waarschuwing: U heeft geen rechten deze instellingen te wijzigen!';