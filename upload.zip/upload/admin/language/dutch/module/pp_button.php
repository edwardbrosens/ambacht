<?php
// Heading
$_['heading_title']       = 'PayPal Express Checkout Button';

// Text
$_['text_module']   = 'Modules';
$_['text_success']  = 'Success: You have modified module PP Layout!';
$_['text_edit']     = 'Instellingen wijzigen';

// Entry
$_['entry_status']        = 'Status';

// Error
$_['error_permission']    = 'Warning: You do not have permission to modify module PP Layout!';