<?php
// HTTP
define('HTTP_SERVER', 'http://54.171.196.6/admin/');
define('HTTP_CATALOG', 'http://54.171.196.6/');

// HTTPS
define('HTTPS_SERVER', 'http://54.171.196.6/admin/');
define('HTTPS_CATALOG', 'http://54.171.196.6/');

// DIR
define('DIR_APPLICATION', '/opt/bitnami/apache2/htdocs/ambacht/upload/admin/');
define('DIR_SYSTEM', '/opt/bitnami/apache2/htdocs/ambacht/upload/system/');
define('DIR_IMAGE', '/opt/bitnami/apache2/htdocs/ambacht/upload/image/');
define('DIR_LANGUAGE', '/opt/bitnami/apache2/htdocs/ambacht/upload/admin/language/');
define('DIR_TEMPLATE', '/opt/bitnami/apache2/htdocs/ambacht/upload/admin/view/template/');
define('DIR_CONFIG', '/opt/bitnami/apache2/htdocs/ambacht/upload/system/config/');
define('DIR_CACHE', '/opt/bitnami/apache2/htdocs/ambacht/upload/system/storage/cache/');
define('DIR_DOWNLOAD', '/opt/bitnami/apache2/htdocs/ambacht/upload/system/storage/download/');
define('DIR_LOGS', '/opt/bitnami/apache2/htdocs/ambacht/upload/system/storage/logs/');
define('DIR_MODIFICATION', '/opt/bitnami/apache2/htdocs/ambacht/upload/system/storage/modification/');
define('DIR_UPLOAD', '/opt/bitnami/apache2/htdocs/ambacht/upload/system/storage/upload/');
define('DIR_CATALOG', '/opt/bitnami/apache2/htdocs/ambacht/upload/catalog/');

// DB
define('DB_DRIVER', 'mpdo');
define('DB_HOSTNAME', '127.0.0.1');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', 'M2MOx7gazzu2');
define('DB_DATABASE', 'wareambacht');
define('DB_PORT', '3306');
define('DB_PREFIX', 'oc_');
